# Play Store release checklist

1. Create/verify Google Play Console developer account.
2. Create the app in Play Console with package `com.shiftbrain.app`.
3. Upload the release AAB produced by GitHub Actions.
4. Complete Store listing, App content, Data safety and pricing/distribution.
5. Publish the privacy page from `docs/privacy-policy.html` and replace the two placeholders first.
6. Use Internal testing first.
7. If the Play developer account is a new personal account created after 13 Nov 2023, run a closed test with at least 12 opted-in testers continuously for 14 days before requesting production access.
8. Fix all crashes and policy warnings.
9. Request production access.
10. Publish to production after approval.
