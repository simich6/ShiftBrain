Package: com.shiftbrain.app
App name: ShiftBrain
Version: 1.0.0 (1)
Default language: English
Additional languages: Italian, Spanish
Category: Business
Target: professional industrial users
Target SDK: 36 (Android 16)
