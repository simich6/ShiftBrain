# Google Play Data Safety — MVP draft

Current MVP behavior:
- No account creation.
- No personal data collected by ShiftBrain.
- No personal data shared with third parties.
- No advertising SDK.
- No location, contacts, microphone, camera, SMS or call permissions.
- Investigation text and language preference are stored locally on the device.

Important: re-check this declaration before every release. If cloud AI, authentication, analytics, crash reporting, payments, document upload or synchronization are enabled, update both the Data Safety form and the Privacy Policy.
