@echo off
setlocal
where flutter >nul 2>nul
if errorlevel 1 (echo Flutter is not installed or not on PATH. & pause & exit /b 1)
call flutter pub get
if errorlevel 1 (pause & exit /b 1)
call flutter build appbundle --release
if errorlevel 1 (pause & exit /b 1)
echo.
echo AAB created at build\app\outputs\bundle\release\app-release.aab
pause
