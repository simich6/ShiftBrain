import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart' show rootBundle;
import 'package:shared_preferences/shared_preferences.dart';
import 'package:http/http.dart' as http;

const bg = Color(0xFF07111F);
const surface = Color(0xFF0D1B2A);
const surface2 = Color(0xFF102338);
const cyan = Color(0xFF25D9FF);
const purple = Color(0xFF8B5CF6);

void main() => runApp(const ShiftBrainApp());

String tr(String lang, String en, String it, String es) => lang == 'IT' ? it : lang == 'ES' ? es : en;

class ShiftBrainApp extends StatefulWidget {
  const ShiftBrainApp({super.key});
  @override State<ShiftBrainApp> createState() => _ShiftBrainAppState();
}
class _ShiftBrainAppState extends State<ShiftBrainApp> {
  String lang = 'EN';
  @override void initState() { super.initState(); _load(); }
  Future<void> _load() async { final p = await SharedPreferences.getInstance(); if (mounted) setState(() => lang = p.getString('lang') ?? 'EN'); }
  Future<void> setLang(String v) async { final p = await SharedPreferences.getInstance(); await p.setString('lang', v); if (mounted) setState(() => lang = v); }
  @override Widget build(BuildContext context) => MaterialApp(
    debugShowCheckedModeBanner: false,
    title: 'ShiftBrain',
    theme: ThemeData.dark(useMaterial3: true).copyWith(
      scaffoldBackgroundColor: bg,
      colorScheme: ColorScheme.fromSeed(seedColor: cyan, brightness: Brightness.dark),
      cardTheme: const CardThemeData(color: surface, margin: EdgeInsets.zero),
      inputDecorationTheme: InputDecorationTheme(filled: true, fillColor: surface2, border: OutlineInputBorder(borderRadius: BorderRadius.circular(14))),
    ),
    home: Shell(lang: lang, onLang: setLang),
  );
}

class Shell extends StatefulWidget {
  final String lang; final Future<void> Function(String) onLang;
  const Shell({super.key, required this.lang, required this.onLang});
  @override State<Shell> createState() => _ShellState();
}
class _ShellState extends State<Shell> {
  int tab = 0; String anomaly = '';
  @override Widget build(BuildContext context) {
    final pages = [Dashboard(lang: widget.lang, onStart: (v) => setState(() { anomaly = v; tab = 1; })), Troubleshoot(lang: widget.lang, initial: anomaly), Knowledge(lang: widget.lang), const Cases(), Settings(lang: widget.lang, onLang: widget.onLang)];
    final labels = [tr(widget.lang,'Home','Home','Inicio'), tr(widget.lang,'Troubleshoot','Diagnosi','Diagnóstico'), tr(widget.lang,'Knowledge','Conoscenza','Conocimiento'), tr(widget.lang,'Cases','Casi','Casos'), tr(widget.lang,'Settings','Impostazioni','Ajustes')];
    return Scaffold(
      appBar: AppBar(
        backgroundColor: bg,
        titleSpacing: 18,
        title: Row(children: [Container(width: 34, height: 34, decoration: BoxDecoration(borderRadius: BorderRadius.circular(10), gradient: const LinearGradient(colors: [cyan, purple])), child: const Icon(Icons.bolt, color: Colors.white)), const SizedBox(width: 10), const Text('SHIFTBRAIN', style: TextStyle(fontWeight: FontWeight.w900, letterSpacing: 1.4))]),
        actions: [PopupMenuButton<String>(initialValue: widget.lang, onSelected: widget.onLang, itemBuilder: (_) => const [PopupMenuItem(value:'EN', child: Text('🇬🇧 English')), PopupMenuItem(value:'IT', child: Text('🇮🇹 Italiano')), PopupMenuItem(value:'ES', child: Text('🇪🇸 Español'))])],
      ),
      body: pages[tab],
      bottomNavigationBar: NavigationBar(selectedIndex: tab, onDestinationSelected: (i) => setState(() => tab = i), destinations: [
        NavigationDestination(icon: const Icon(Icons.home_outlined), selectedIcon: const Icon(Icons.home), label: labels[0]),
        NavigationDestination(icon: const Icon(Icons.biotech_outlined), selectedIcon: const Icon(Icons.biotech), label: labels[1]),
        NavigationDestination(icon: const Icon(Icons.account_tree_outlined), selectedIcon: const Icon(Icons.account_tree), label: labels[2]),
        NavigationDestination(icon: const Icon(Icons.folder_open), selectedIcon: const Icon(Icons.folder), label: labels[3]),
        NavigationDestination(icon: const Icon(Icons.settings_outlined), selectedIcon: const Icon(Icons.settings), label: labels[4]),
      ]),
    );
  }
}

class Dashboard extends StatelessWidget {
  final String lang; final ValueChanged<String> onStart; const Dashboard({super.key, required this.lang, required this.onStart});
  @override Widget build(BuildContext context) => ListView(padding: const EdgeInsets.all(18), children: [
    const SizedBox(height: 8), Text(tr(lang,'Turn problems into solutions','Trasforma i problemi in soluzioni','Convierte problemas en soluciones'), style: const TextStyle(fontSize: 30, fontWeight: FontWeight.w900)),
    const SizedBox(height: 8), Text(tr(lang,'Industrial troubleshooting powered by science, experience & AI.','Troubleshooting industriale powered by scienza, esperienza e AI.','Troubleshooting industrial impulsado por ciencia, experiencia e IA.'), style: const TextStyle(color: Colors.white60, height: 1.4)),
    const SizedBox(height: 22), _hero(context), const SizedBox(height: 14),
    Row(children: [Expanded(child: _stat('Knowledge','51',Icons.account_tree)), const SizedBox(width: 10), Expanded(child: _stat('Failure modes','12',Icons.warning_amber))]),
    const SizedBox(height: 14), _section(context, tr(lang,'Start an investigation','Avvia un’investigazione','Iniciar una investigación')),
  ]);
  Widget _hero(BuildContext c) => Container(padding: const EdgeInsets.all(20), decoration: BoxDecoration(borderRadius: BorderRadius.circular(22), gradient: const LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: [Color(0xFF102B42), Color(0xFF15102D)])), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [const Icon(Icons.auto_awesome, color: cyan, size: 30), const SizedBox(height: 12), Text(tr(lang,'AI RCA Copilot','AI RCA Copilot','Copiloto AI de RCA'), style: const TextStyle(fontSize: 21, fontWeight: FontWeight.w800)), const SizedBox(height: 7), Text(tr(lang,'Define → Evidence → Eliminate → Verify','Definisci → Evidenze → Elimina → Verifica','Define → Evidencia → Elimina → Verifica'), style: const TextStyle(color: Colors.white70)), const SizedBox(height: 15), FilledButton(onPressed: () => onStart(''), child: Text(tr(lang,'New investigation','Nuova investigazione','Nueva investigación')))]));
  Widget _stat(String label, String value, IconData icon) => Card(child: Padding(padding: const EdgeInsets.all(16), child: Row(children: [Icon(icon, color: cyan), const SizedBox(width: 10), Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(value, style: const TextStyle(fontSize: 24, fontWeight: FontWeight.w900)), Text(label, style: const TextStyle(color: Colors.white60))])])));
  Widget _section(BuildContext context, String title) => Card(child: Padding(padding: const EdgeInsets.all(16), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(title, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800)), const SizedBox(height: 12), OutlinedButton.icon(onPressed: () => onStart('Vacuum does not reach setpoint during primary drying'), icon: const Icon(Icons.search), label: Text(tr(lang,'Try a vacuum investigation','Prova un’indagine sul vuoto','Probar una investigación de vacío')))])));
}

class Troubleshoot extends StatefulWidget { final String lang, initial; const Troubleshoot({super.key, required this.lang, required this.initial}); @override State<Troubleshoot> createState() => _TroubleshootState(); }
class _TroubleshootState extends State<Troubleshoot> {
  late TextEditingController input; int step = 0; final Map<String, bool> checked = {};
  final causes = [['Vacuum leak', 78, 'Perform isolation / leak test'], ['Vacuum pump performance', 54, 'Check pump-down / performance'], ['Valve leakage', 41, 'Check valve isolation / seat']];
  @override void initState(){ super.initState(); input = TextEditingController(text: widget.initial); }
  @override void dispose(){ input.dispose(); super.dispose(); }
  @override Widget build(BuildContext context) => ListView(padding: const EdgeInsets.all(18), children: [
    Text(tr(widget.lang,'Troubleshoot','Diagnosi','Diagnóstico'), style: const TextStyle(fontSize: 28, fontWeight: FontWeight.w900)), const SizedBox(height: 6),
    Text(tr(widget.lang,'A hypothesis is not a root cause until verified.','Un’ipotesi non è una root cause finché non viene verificata.','Una hipótesis no es causa raíz hasta que se verifica.'), style: const TextStyle(color: Colors.white60)), const SizedBox(height: 16),
    Card(child: Padding(padding: const EdgeInsets.all(16), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(tr(widget.lang,'What happened?','Cosa è successo?','¿Qué ocurrió?')), const SizedBox(height: 9), TextField(controller: input, maxLines: 4, decoration: InputDecoration(hintText: tr(widget.lang,'Describe the anomaly...','Descrivi l’anomalia...','Describe la anomalía...'))), const SizedBox(height: 12), SizedBox(width: double.infinity, child: FilledButton.icon(onPressed: () => setState(() => step++), icon: const Icon(Icons.auto_awesome), label: Text(tr(widget.lang,'Analyze','Analizza','Analizar'))))])),
    const SizedBox(height: 14), _card(tr(widget.lang,'Diagnostic ranking','Ranking diagnostico','Ranking diagnóstico'), Column(children: causes.map(_cause).toList())),
    const SizedBox(height: 14), _card(tr(widget.lang,'Next Best Check','Prossimo controllo','Siguiente comprobación'), ListTile(contentPadding: EdgeInsets.zero, leading: const Icon(Icons.science, color: cyan), title: Text(causes[step % causes.length][2].toString()), subtitle: Text(tr(widget.lang,'Selected to discriminate between the leading hypotheses.','Scelto per discriminare tra le ipotesi principali.','Elegido para discriminar entre las hipótesis principales.')), trailing: FilledButton(onPressed: () => setState(() => step++), child: Text(tr(widget.lang,'Record','Registra','Registrar'))))),
    const SizedBox(height: 14), _card('RCA status', Row(children: [Icon(step == 0 ? Icons.pending_outlined : Icons.check_circle_outline, color: step == 0 ? Colors.orange : cyan), const SizedBox(width: 10), Expanded(child: Text(step == 0 ? tr(widget.lang,'Hypothesis — verification pending','Ipotesi — verifica in attesa','Hipótesis — verificación pendiente') : tr(widget.lang,'Evidence updated — continue verification','Evidenza aggiornata — continua la verifica','Evidencia actualizada — continuar verificación')))])),
  ]);
  Widget _cause(List<dynamic> c){ final base = c[1] as int; final s = base - (checked[c[0].toString()] == true ? 25 : 0); return ListTile(contentPadding: EdgeInsets.zero, leading: CircleAvatar(child: Text('$s')), title: Text(c[0].toString()), subtitle: Padding(padding: const EdgeInsets.only(top: 7), child: LinearProgressIndicator(value: s / 100)), trailing: IconButton(onPressed: () => setState(() => checked[c[0].toString()] = true), icon: const Icon(Icons.check_circle_outline))); }
  Widget _card(String title, Widget child) => Card(child: Padding(padding: const EdgeInsets.all(16), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(title, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800)), const SizedBox(height: 9), child])));
}

class Knowledge extends StatefulWidget { final String lang; const Knowledge({super.key, required this.lang}); @override State<Knowledge> createState()=>_KnowledgeState(); }
class _KnowledgeState extends State<Knowledge>{ List<dynamic> items=[]; bool loading=true; String filter=''; @override void initState(){super.initState();_load();}
  Future<void> _load() async { final out=<dynamic>[]; for(final p in ['assets/knowledge/engineering_knowledge.json','assets/knowledge/science.json']) { try { final x=jsonDecode(await rootBundle.loadString(p)); if(x is List) out.addAll(x); else if(x is Map){ for(final k in ['parameters','components','failure_modes','relationships','sources','case_studies','items']) { if(x[k] is List) out.addAll(x[k]); } } } catch(_){ } } if(mounted)setState(()=>{items=out,loading=false}); }
  @override Widget build(BuildContext context){ final shown=items.where((x){final s=jsonEncode(x).toLowerCase();return s.contains(filter.toLowerCase());}).toList(); return Column(children:[Padding(padding:const EdgeInsets.fromLTRB(18,14,18,10),child:TextField(onChanged:(v)=>setState(()=>filter=v),decoration:InputDecoration(prefixIcon:const Icon(Icons.search),hintText:tr(widget.lang,'Search parameters, components, failure modes...','Cerca parametri, componenti, failure modes...','Buscar parámetros, componentes, modos de fallo...')))),Expanded(child:loading?const Center(child:CircularProgressIndicator()):ListView.builder(padding:const EdgeInsets.fromLTRB(18,4,18,18),itemCount:shown.length,itemBuilder:(c,i){final x=shown[i];final name=x is Map?(x['name']??x['title']??x['key']??'Knowledge item').toString():'Knowledge item';final desc=x is Map?(x['description']??x['finding']??x['summary']??'').toString():'';return Card(margin:const EdgeInsets.only(bottom:9),child:ListTile(leading:const Icon(Icons.hub_outlined,color:cyan),title:Text(name),subtitle:Text(desc,maxLines:2,overflow:TextOverflow.ellipsis)));}))]); }
}
class Cases extends StatelessWidget { const Cases({super.key}); @override Widget build(BuildContext context)=>Center(child:Padding(padding:const EdgeInsets.all(30),child:Column(mainAxisSize:MainAxisSize.min,children:[const Icon(Icons.folder_copy_outlined,size:54,color:cyan),const SizedBox(height:12),const Text('No investigations yet',style:TextStyle(fontSize:19,fontWeight:FontWeight.w800)),const SizedBox(height:6),Text('Your verified investigations and RCA reports will appear here.',textAlign:TextAlign.center,style:TextStyle(color:Colors.white60))]))); }
class Settings extends StatelessWidget { final String lang; final Future<void> Function(String) onLang; const Settings({super.key,required this.lang,required this.onLang}); @override Widget build(BuildContext context)=>ListView(padding:const EdgeInsets.all(18),children:[Text(tr(lang,'Settings','Impostazioni','Ajustes'),style:const TextStyle(fontSize:28,fontWeight:FontWeight.w900)),const SizedBox(height:16),Card(child:Column(children:[ListTile(leading:const Icon(Icons.language,color:cyan),title:Text(tr(lang,'Language','Lingua','Idioma')),subtitle:Text(lang),trailing:DropdownButton<String>(value:lang,items:const [DropdownMenuItem(value:'EN',child:Text('English')),DropdownMenuItem(value:'IT',child:Text('Italiano')),DropdownMenuItem(value:'ES',child:Text('Español'))],onChanged:(v){if(v!=null)onLang(v);})),const Divider(height:1),const ListTile(leading:Icon(Icons.cloud_outlined),title:Text('AI / API'),subtitle:Text('Connect a ShiftBrain backend in the production build.')),const ListTile(leading:Icon(Icons.shield_outlined),title:Text('Privacy'),subtitle:Text('No plant documents are uploaded by this offline MVP.'))]))]); }
