# Run from the ShiftBrain_Android_v1 directory after installing Flutter.
flutter create . --platforms=android
flutter pub get
flutter run
