#!/usr/bin/env bash
set -e
flutter pub get
flutter build appbundle --release
echo "AAB: build/app/outputs/bundle/release/app-release.aab"
