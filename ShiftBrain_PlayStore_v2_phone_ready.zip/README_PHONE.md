# ShiftBrain — build entirely from your phone

You do NOT need a PC to build the Android App Bundle if you use GitHub Actions.

## Phone-only route
1. Create a GitHub account and a new repository named `shiftbrain`.
2. Upload this project ZIP contents from your phone (GitHub mobile/browser is fine).
3. In the repository, open **Actions** and run **Build ShiftBrain Android**.
4. Download the generated `shiftbrain-aab` artifact from the workflow run.
5. In Google Play Console, create `ShiftBrain` with package `com.shiftbrain.app` and upload the AAB.

## Release signing
For production, create an upload keystore and store its Base64 value as the GitHub secret `SHIFTBRAIN_KEYSTORE_BASE64`, plus:
- `SHIFTBRAIN_KEYSTORE_PASSWORD`
- `SHIFTBRAIN_KEY_ALIAS`
- `SHIFTBRAIN_KEY_PASSWORD`
- optional `SHIFTBRAIN_API_URL`

Never commit the keystore or passwords.

## Privacy page
The Pages workflow publishes `/docs` as a public site. Enable GitHub Pages with **GitHub Actions** as the source, and replace the privacy contact placeholders before using the URL in Play Console.

## Important
The MVP currently works offline and does not collect personal data. Cloud AI/RAG is intentionally not hard-coded with a secret API key in the mobile app. Add a secure backend before enabling production AI features.
