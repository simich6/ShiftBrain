# ShiftBrain Android — Play Store MVP

Production-oriented Flutter foundation for **ShiftBrain — Industrial Troubleshooting Copilot**.

## Run

```bash
flutter pub get
flutter run
```

## Build for Google Play

```bash
flutter build appbundle --release
```

Output: `build/app/outputs/bundle/release/app-release.aab`

### Important before publishing
- Replace the debug signing config in `android/app/build.gradle` with a private release keystore.
- Create a Play Console developer account and complete the app content/privacy declarations.
- Host a public Privacy Policy URL before release.
- Configure the production ShiftBrain API endpoint and authentication.
- Review Android permissions; the MVP intentionally requests none.
- Do not upload confidential plant documents to a public backend without the required enterprise security controls.

## Product scope
- English default, Italian and Spanish.
- Mobile-first troubleshooting flow.
- Deterministic diagnostic ranking UX.
- Next Best Check UX.
- Offline Engineering + Scientific Knowledge assets.
- Architecture ready for cloud AI/RAG, plant knowledge and historical investigations.

Diagnostic scores are heuristics, not statistical probabilities or acceptance criteria.
